;game of life on 128x64 OLED display
;10/24/19
; replace cp 0 with or a as suggested by Alan Cox
; change the representation of mark-for-death to 0x10 and living to 0x1
;   this will simplify the summing operation of the eight neighbor pixels.
;10/22/19
;rules:
; 4 or more cause death
; 3 causes birth
; 2 or 3 no change
; 1 or less causes death
; scan the whole map and mark-for-birth (0x80) or mark-for-death (0x10)
; go over the whole map and convert 0x10 to 0 and 0x80 to 0x1
; send the map to 128x64 OLED by bit-bang I2C

I2C	equ 9eh		;bit bang I/O address of I2C


	org 1000h
	jp start
error	db 0		
init:				;initial data, organized as line + pixel offset 
;	dw array+3*128+25		;this is setup for Gosper glider gun from Wikipedia
;	dw array+4*128+23
;	dw array+4*128+25
;	dw array+5*128+13
;	dw array+5*128+14
;	dw array+5*128+21
;	dw array+5*128+22
;	dw array+5*128+35
;	dw array+5*128+36
;	dw array+6*128+12
;	dw array+6*128+16
;	dw array+6*128+21
;	dw array+6*128+22
;	dw array+6*128+35
;	dw array+6*128+36
;	dw array+7*128+1
;	dw array+7*128+2
;	dw array+7*128+11
;	dw array+7*128+17
;	dw array+7*128+21
;	dw array+7*128+22
;	dw array+8*128+1
;	dw array+8*128+2
;	dw array+8*128+11
;	dw array+8*128+15
;	dw array+8*128+17
;	dw array+8*128+18
;	dw array+8*128+23
;	dw array+8*128+25
;	dw array+9*128+11
;	dw array+9*128+17
;	dw array+9*128+25
;	dw array+10*128+12
;	dw array+10*128+16
;	dw array+11*128+13
;	dw array+11*128+14

;;;;;;EVE:::::::::::::
;RLE file is: 14bo$14bo$15bo$9bo3b2o$7bo4b3o$7bo3bo$9b2o$bo$3o$obo!

;	dw array+(n+)*128+p+

;	dw array+10*128+30+14
;	dw array+(10+1)*128+30+14
;	dw array+(10+2)*128+30+15
;	dw array+(n+3)*128+p+9
;	dw array+(n+3)*128+p+13
;	dw array+(n+3)*128+p+14
;	dw array+(n+4)*128+p+7
;	dw array+(n+4)*128+p+12
;	dw array+(n+4)*128+p+13
;	dw array+(n+4)*128+p+14
;	dw array+(n+5)*128+p+7
;	dw array+(n+5)*128+p+11
;	dw array+(n+6)*128+p+9
;	dw array+(n+6)*128+p+10
;	dw array+(n+7)*128+p+1
;	dw array+(n+8)*128+p+0
;	dw array+(n+8)*128+p+1
;	dw array+(n+8)*128+p+2
;	dw array+(n+9)*128+p+0
;	dw array+(n+9)*128+p+2

	dw array+24*128+50+14
	dw array+(24+1)*128+50+14
	dw array+(24+2)*128+50+15
	dw array+(24+3)*128+50+9
	dw array+(24+3)*128+50+13
	dw array+(24+3)*128+50+14
	dw array+(24+4)*128+50+7
	dw array+(24+4)*128+50+12
	dw array+(24+4)*128+50+13
	dw array+(24+4)*128+50+14
	dw array+(24+5)*128+50+7
	dw array+(24+5)*128+50+11
	dw array+(24+6)*128+50+9
	dw array+(24+6)*128+50+10
	dw array+(24+7)*128+50+1
	dw array+(24+8)*128+50+0
	dw array+(24+8)*128+50+1
	dw array+(24+8)*128+50+2
	dw array+(24+9)*128+50+0
	dw array+(24+9)*128+50+2

initend:				;end of initialization data

start:
	di
	ld sp,stack
	ld hl,error		;clear the error flag
	xor a
	ld (hl),a

	call initOLED		;initialize the SSD1306
	call clearOLED		;clear the array memory

; set initial condition
	ld a,1h			;the living cell value is 0x1
	ld b,initend-init		;size of the initialization table
	ld hl,init		;point to initialization data
initloop
	ld e,(hl)			;get the LSB
	inc hl
	ld d,(hl)			;get the MSB
	inc hl
	ld (de),a			;initialize the pixel
	dec b			;decrement b twice per pass
	djnz initloop

	call wOLED		;write out the inialized data
	call delay
	call delay

life:
;line starts from line 0 to line 63
;pixel position starts form 0 to 127
; scan from line 1 to line 62,
; for each line scan pixel position 1 to 126

	ld hl,array+128+1		;point to 2nd line, 2nd pixel
	ld d,62			;scan 62 lines
nxtline:
	ld b,126			;scan 126 pixels per line
oneline:
	call scan			;scan the 8 neighboring pixels
	inc hl
	djnz oneline
	inc hl			;after increment, ix points at first pixel of new line
	inc hl			;after increment, ix points at 2nd pixel of new line
	dec d
	jp nz,nxtline

; go over all cells and write 0 to cells marked for death and write 0x1 to cells
;   mark for birth

	ld hl,array+128+1		;start from 2nd line, 2nd pixel
	ld d,62			;scan 62 lines
update1:
	ld b,126			;scan 126 pixels per line
update:
	ld a,(hl)			;get the cell
	cp 10h			;if living (0x1) and dead (0x0), do nothing
	jp m,nxtcell
	jp z,mrkdeath		;mark for death (0x10)?
;otherwise it is 0x80, mark-for-birth
mrkbirth:
	ld a,1h			;write 1 to cell
	ld (hl),a
	jp nxtcell
mrkdeath:
	xor a
	ld (hl),a			;write 0 to cell
nxtcell:
	inc hl
	djnz update
	dec d
	inc hl			;after increment, hl points at first pixel of new line
	inc hl			;after increment, hl points at 2nd pixel of new line
	jp nz,update1

;write data to OLED
	call wOLED

	jp life			;loop forever

;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
delay:
	push bc
	push af
	ld bc,0
delay1:
	nop
	dec bc
	ld a,b
	or a		;cp 0
	jp nz,delay1
	pop af
	pop bc
	ret
scan:
; look at the 8 pixels around the current position pointed by ix
	push de
	push hl
	xor a		;start with no living adjacent cell
	ld de,129
	sbc hl,de		;start with above left pixel
	add a,(hl)
	inc hl		;above pixel
	add a,(hl)
	inc hl		;above right pixel
	add a,(hl)
	ld de,126
	add hl,de		;left pixel
	add a,(hl)
	inc hl
	inc hl
	add a,(hl)	;right pixel
	add hl,de		;below left pixel
	add a,(hl)
	inc hl		;below pixel
	add a,(hl)
	inc hl		;below right pixel
; no need to worry about the case of 8 neighbors all mark-for-death
;   that condition can not happen, so the msb bit is never 1
	add a,(hl)
	and 07fh		;the msb bit should not be 1
	pop hl		;restore original hl
; A now contains the total number of living cells and mark-for-death cells
	ld e,a		;save
	and 0fh		;get total number of living cells
	ld d,a		;save it
	ld a,e		;restore
	and 0f0h
	rrca		;move high nibble to low nibble
	rrca
	rrca
	rrca
	add a,d		;A contains the total number of living neighbors

	cp 2		;if lesser than 2, mark for death; if 2, nothing
	jp z,nothing
	jp m,death
	cp 3		;if 3 and living, nothing; if 3 and dead, mark for living
	jp z,chkstat	
; 4 or more living neighbor.  If dead, nothing; if living, mark-for-death
death:
	ld a,(hl)
	or a		;(cp 0) if current cell is living, mark for death
	jp z,nothing	;if not living, do nothing
	ld a,10h		;mark for death
	ld (hl),a
	jp nothing
chkstat:
; 3 living neighbor, if cell is living, do nothing, if dead, mark for birth
	ld a,(hl)
	or a		;cp 0
	jp nz,nothing	;cell is living, do nothing
	ld a,80h
	ld (hl),a		;mark cell for birth
nothing:
	pop de
	ret

clearOLED:
; clear array
	ld hl,array		;point to array
	ld e,32			;outer loop counter
	ld b,0			;inner loop is 256
	xor a
clrOLED1:
	ld (hl),a			;clear memory
	inc hl
	djnz clrOLED1
	dec e			;outer loop
	jp nz,clrOLED1
	ret

initOLED:
;;;;;;;;;;;;;;;;;;; Should be table driven ;;;;;;;;;;
	call i2cs		;start
	ld c,078h		;SSD1306 address
	call wi2c
	ld c,0aeh		;turn off display
	call wi2c
   	ld c,0d5h		;set display clock div
	call wi2c
	ld c,080h		;ratio 0x80
	call wi2c
	ld c,000h		;set multiplex
	call wi2c
	ld c,03fh		; 128x32
	call wi2c
	ld c,0d3h		;set display offset
	call wi2c
	ld c,000h		
	call wi2c		
	ld c,040h		;set startline
	call wi2c
	ld c,08dh		;charge pump
	call wi2c
	ld c,014h		;vccstate 14
	call wi2c
	ld c,020h		;memorymode
	call wi2c
	ld c,000h		
	call wi2c
;	ld c,0a1h		;a0 upside down segremap
;	call wi2c
;	ld c,0c8h		;com scan dec
;	call wi2c
	ld c,0dah		;set com pins
	call wi2c
	ld c,012h		; 02 128x32 12
	call wi2c
	ld c,081h		; set contrast
	call wi2c
	ld c,0ffh		;contrast
	call wi2c
	ld c,0d9h		;set precharge
	call wi2c
	ld c,0f1h		;vcc state f1
	call wi2c
	ld c,0dbh		;set vcom detect
	call wi2c
	ld c,040h
	call wi2c
	ld c,0a4h		;display all on resume
	call wi2c
	ld c,0a6h		;normal display
	call wi2c
	ld c,0afh		;display on
	call wi2c
	call i2cp
	ret

wOLED:
; write entire screen of data
; clumpsy-each data byte to the display is consists of 8 lines, with the msb bit the 8th line
;   and the lsb bit the first line.  So start with the 8th line, send off the bit on I2C, go back 128 pixels
;   and ship off the next bit, so on.
	call i2cs		;start
	ld c,078h		;SSD1306 address
	call wi2c
	ld c,40h		;data
	call wi2c
	ld e,8		;do 8 lines, each line is 8 pixels tall
	push de		;save line count
	ld hl,array	;point to screen data array
wwdatnxtl:
	ld c,128		;a line is 128 bytes
wwdatnxtb:
	ld b,8		;a byte is 8 pixels in vertical direction
	push hl		;save
	ld de,896
	add hl,de
	ld de,128
wwdat:
	xor a		;clear carry bit	
	ld a,(hl)		;get screen array at current location
	sbc hl,de		;pixel in vertical direction, -128 apart
	or a		;cp 0
	jp nz,wwdathi
;;;;;;;;;;;;;;;;;;;;;;;;;;
;	call bit0
;place bit0 routine inline
; reg a is 0 right now
	out (I2C),a	;change to 0 while clock low
	ld a,0fh
	out (I2C),a	;clock high, data 0
	xor a
;	out (I2C),a	;clock low, data 0
;;;;;;;;;;;;;;;;;;;;;;;;;;
	jp nxtpix
wwdathi:
;;;;;;;;;;;;;;;;;;;;;;;
;	call bit1
;place bit1 routine inline
	ld a,80h
	out (I2C),a	;change to 1 while clock low
	ld a,0ffh
	out (I2C),a	;clock high, data 1
	ld a,80h
;	out (I2C),a	;clock low, data 1
;;;;;;;;;;;;;;;;;
nxtpix:
	dec b
	out (I2C),a	;this won't change the conditional flags
	jp nz,wwdat
;	djnz wwdat	;do a byte of data
	call sAck		;done one byte of data, wait for slave acknowledge
	pop hl
	inc hl
	dec c
	jp nz,wwdatnxtb
;finish one line of 8-bit character, need to do 8 lines
;next line is 8x128 away
	ld de,896		;HL has reached the beginning of a new line at this point
	add hl,de
	pop de		;restore line count 
	dec e		;do 8 lines, each line is 8 pixels tall
          push de		;save it again
	jp nz,wwdatnxtl
	pop de		;clean up stack
	jp i2cp		;STOP command, return to calling routine

i2cs:
; I2C START command
	ld a,0ffh
	out (I2C),a	;set SCL and SDA high
	nop
	nop
	nop
	nop
	nop
	nop
	ld a,1
	out (I2C),a	;START
	nop
	nop
	nop
	nop
	nop
	nop
	nop
	xor a
	out (I2C),a	;clock low
	ret
i2cp:
;I2C STOP command
	xor a		;clock low, data low
	out (I2C),a
	ld a,1		;clock high, data low
	out (I2C),a
	nop
	nop
	nop
	nop
	ld a,0ffh		;data goes high while clock high (STOP)
	out (I2C),a
	ret

wi2c:
; write value in reg C to I2C bitbang register
	bit 7,c
	jr z,call70
	call bit1
	jr do6
call70:	call bit0
do6:	bit 6,c
	jr z,call60
	call bit1
	jr do5
call60:	call bit0
do5:	bit 5,c
	jr z,call50
	call bit1
	jr do4
call50:	call bit0
do4:	bit 4,c
	jr z,call40
	call bit1
	jr do3
call40:	call bit0
do3:	bit 3,c
	jr z,call30
	call bit1
	jr do2
call30:	call bit0
do2:	bit 2,c
	jr z,call20
	call bit1
	jr do1
call20:	call bit0
do1:	bit 1,c
	jr z,call10
	call bit1
	jr do0
call10:	call bit0
do0:	bit 0,c
	jr z,call00
	call bit1
	jp sAck		;slave acknowledge and return
call00:	call bit0
dosack:
	jp sAck		;slave acknowledge and return

readbit:
; read one bit into reg B
	ld a,80h
	out (I2C),a	;change to 1 while clock low
	ld a,0ffh
	out (I2C),a	;clock high, data 1
	nop
	in a,(I2C)	;read data into D7
	and 80h		;mask off other bits
	or b
	rlca		;move to lsb
	ld b,a	
	ld a,80h
	out (I2C),a	;clock low, data 1
	ret

sAck:	
	ld a,80h		;wait for acknowledge
	out (I2C),a
;	nop
;	nop
;	nop
;	nop
;	nop
;	nop
;	nop
;	nop
	nop
	nop
	nop
	ld a,0ffh		;clock high with data high, expect slave to pull it low
	out (I2C),a
	nop
	in a,(I2C)	;read slave acknowledge
	and 80h		;expect it to be low for slave acknowledge
	jp nz,errormsg

	ld a,80h
	out (I2C),a	;clock low with data high
	nop
	nop
	nop

	ret
errormsg:

	
	ld a,1
	out (I2C),a	;clock high data low
	nop
	nop
	nop
	nop
	ld a,(error)
	or 80h
	ld (error),a	;set error flag
	nop
	nop
	nop
	nop
	nop
	nop
	nop
	ld a,0ffh
	out (I2C),a	;data low to high while clock high (STOP)

	jp 0b400h		;return to command prompt
bit0:
	xor a
	out (I2C),a	;change to 0 while clock low
	ld a,0fh
	out (I2C),a	;clock high, data 0
;	nop
;	nop
;	nop
;	nop
;	nop
;	nop
	nop
	nop
	xor a
	out (I2C),a	;clock low, data 0
	ret
bit1:
	ld a,80h
	out (I2C),a	;change to 1 while clock low
	ld a,0ffh
	out (I2C),a	;clock high, data 1
;	nop
;	nop
;	nop
;	nop
;	nop
;	nop
	nop
	nop
	ld a,80h
	out (I2C),a	;clock low, data 1
	ret

	ds 128		;reserve a chunk of memory for stack
stack:

	org 4000h
array:
;64 pixels tall by 128 pixels across, each pixel represented by one byte
	ds 8192

